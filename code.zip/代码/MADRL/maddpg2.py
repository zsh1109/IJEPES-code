import argparse
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import math

import os, sys, random
import time
from tensorboardX import SummaryWriter 

import misc        

import copy

import scipy.io as sio        

import OPFnew1 as branchflowDDPG    

########################## define DDPG network ######################
# define the network structure for actor and critic；
class ActorNetC(nn.Module):   

    def __init__(self, s_dim, a_dim):
        super(ActorNetC, self).__init__()
        self.fc1 = nn.Linear(s_dim, 90)
        self.fc1.weight.data.normal_(0, 0.1)  
        self.fc2 = nn.Linear(90, 22)
        self.fc2.weight.data.normal_(0, 0.1)  
        self.out = nn.Linear(22, a_dim)
        self.out.weight.data.normal_(0, 0.1) 

    def forward(self, x):
        x = self.fc1(x)
        x = F.relu(x)
        x = self.fc2(x)
        x = F.relu(x)
        x = self.out(x)
        actions = torch.tanh(x)         
        return actions

class ActorNetD(nn.Module):  

    def __init__(self, s_dim, a_dim):
        super(ActorNetD, self).__init__()
        self.fc1 = nn.Linear(s_dim, 90)
        self.fc1.weight.data.normal_(0, 0.1) 
        self.fc2 = nn.Linear(90, 22)
        self.fc2.weight.data.normal_(0, 0.1)  
        self.out = nn.Linear(22, a_dim)
        self.out.weight.data.normal_(0, 0.1) 

    def forward(self, x):
        x = self.fc1(x)
        x = F.relu(x)
        x = self.fc2(x)
        x = F.relu(x)
        x = self.out(x)     
    
        return x


class CriticNet(nn.Module):
    def __init__(self, s_dim, a_dim):
        super(CriticNet, self).__init__()

        self.fc1 = nn.Linear(s_dim + a_dim, 90)    
        self.fc1.weight.data.normal_(0, 0.1)     
        self.fc2 = nn.Linear(90 , 22)
        self.fc2.weight.data.normal_(0, 0.1)     
        self.out = nn.Linear(22, 1)
        self.out.weight.data.normal_(0, 0.1)    

    def forward(self, x, u):
        x = F.relu(self.fc1(torch.cat([x, u], 1)))
        x = F.relu(self.fc2(x))
        actions_value = self.out(x)
        return actions_value

########################## define MADDPG network ######################
class MADDPG(object):    

    def __init__(self, agent1_a_dim, agent1_s_dim, agent2_a_dim, agent2_s_dim, LR_ACTOR, LR_CRITIC, GAMMA, TAU, MEMORY_CAPACITY, BATCH_SIZE, agent1_script_name, agent2_script_name, discrete_action1=None, discrete_action2=None):
        self.agent1_a_dim, self.agent1_s_dim, self.agent2_a_dim, self.agent2_s_dim = agent1_a_dim, agent1_s_dim, agent2_a_dim, agent2_s_dim
        self.LR_ACTOR, self.LR_CRITIC, self.GAMMA, self.TAU, self.MEMORY_CAPACITY, self.BATCH_SIZE = LR_ACTOR, LR_CRITIC, GAMMA, TAU, MEMORY_CAPACITY, BATCH_SIZE    
        self.agent1_script_name = agent1_script_name
        self.agent2_script_name = agent2_script_name
        self.discrete_action1, self.discrete_action2 = discrete_action1, discrete_action2

        self.agent1directory = './exp' + self.agent1_script_name +'./'
        self.agent2directory = './exp' + self.agent2_script_name +'./'

        self.sum_state = self.agent1_s_dim + self.agent2_s_dim
        self.sum_action = self.agent1_a_dim + self.agent2_a_dim

        self.memory = np.zeros((self.MEMORY_CAPACITY, self.sum_state * 2 + self.sum_action + 2), dtype=np.float32)
        self.pointers = 0  
        
        #for agent1
        if self.discrete_action1:
            self.agent1_actor_network = ActorNetD(self.agent1_s_dim, self.agent1_a_dim)
            self.agent1_actor_target_network = ActorNetD(self.agent1_s_dim, self.agent1_a_dim)
        else:
            self.agent1_actor_network = ActorNetC(self.agent1_s_dim, self.agent1_a_dim)
            self.agent1_actor_target_network = ActorNetC(self.agent1_s_dim, self.agent1_a_dim)            
        self.agent1_critic_network = CriticNet(self.agent1_s_dim, self.sum_action)
        self.agent1_critic_target_network = CriticNet(self.agent1_s_dim, self.sum_action) 

        #for agent2
        if self.discrete_action2:
            self.agent2_actor_network = ActorNetD(self.agent2_s_dim, self.agent2_a_dim)
            self.agent2_actor_target_network = ActorNetD(self.agent2_s_dim, self.agent2_a_dim)
        else:
            self.agent2_actor_network = ActorNetC(self.agent2_s_dim, self.agent2_a_dim)
            self.agent2_actor_target_network = ActorNetC(self.agent2_s_dim, self.agent2_a_dim)            
        self.agent2_critic_network = CriticNet(self.agent2_s_dim, self.sum_action)
        self.agent2_critic_target_network = CriticNet(self.agent2_s_dim, self.sum_action)

        # create the optimizer
        self.agent1_actor_optim = torch.optim.Adam(self.agent1_actor_network.parameters(), lr=self.LR_ACTOR)
        self.agent1_critic_optim = torch.optim.Adam(self.agent1_critic_network.parameters(), lr=self.LR_CRITIC)

        self.agent2_actor_optim = torch.optim.Adam(self.agent2_actor_network.parameters(), lr=self.LR_ACTOR)
        self.agent2_critic_optim = torch.optim.Adam(self.agent2_critic_network.parameters(), lr=self.LR_CRITIC)

        # Define the loss function for critic network update 
        self.loss_func = nn.MSELoss()
        # load the weights into the target networks
        self.agent1_actor_target_network.load_state_dict(self.agent1_actor_network.state_dict())
        self.agent1_critic_target_network.load_state_dict(self.agent1_critic_network.state_dict())

        self.agent2_actor_target_network.load_state_dict(self.agent2_actor_network.state_dict())
        self.agent2_critic_target_network.load_state_dict(self.agent2_critic_network.state_dict())

        self.agent1writer = SummaryWriter(self.agent1directory)
        self.agent2writer = SummaryWriter(self.agent2directory)
        self.num_critic_update_iteration = 0
        self.num_actor_update_iteration = 0


    def store_transition(self, agent1state, agent1action, agent1reward, agent1_next_state, agent2state, agent2action, agent2reward, agent2_next_state):
        transitions = np.hstack((agent1state, agent1action, [agent1reward], agent1_next_state, agent2state, agent2action, [agent2reward], agent2_next_state)) #在水平方向平铺数组. 为一维
        indexs = self.pointers % self.MEMORY_CAPACITY  
        self.memory[indexs, :] = transitions
        self.pointers += 1

    def choose_action(self, agent1_s,agent2_s,explore=False):   
        """
        explore (boolean): Whether or not to add exploration noise
        """
      
        agent1_s = torch.unsqueeze(torch.FloatTensor(agent1_s), 0) 
        agent2_s = torch.unsqueeze(torch.FloatTensor(agent2_s), 0) 
        agent1_action = self.agent1_actor_network(agent1_s)  
        agent2_action = self.agent2_actor_network(agent2_s)  

        if self.discrete_action1:    
            if explore:   
                agent1_action = misc.gumbel_softmax(agent1_action, hard= True)   
            else:
                agent1_action = misc.onehot_from_logits(agent1_action)
        else:  
            if explore:    
                agent1_action += torch.tensor(Gnoise(self.pointers, self.MEMORY_CAPACITY, self.agent1_a_dim))
            
            agent1_action = agent1_action.clamp(-1, 1)
                
        
        if self.discrete_action2:    
            if explore:    
                agent2_action = misc.gumbel_softmax(agent2_action, hard= True)   
            else:
                agent2_action = misc.onehot_from_logits(agent2_action)
        else:  
            if explore:    
                agent2_action += torch.tensor(Gnoise(self.pointers, self.MEMORY_CAPACITY, self.agent2_a_dim))
            
            agent2_action = agent2_action.clamp(-1, 1)
        
        return agent1_action[0].detach(),agent2_action[0].detach()      
    
    def learn(self):
        
        indic = np.random.choice(self.MEMORY_CAPACITY, size=self.BATCH_SIZE) 
        batch_transi = self.memory[indic, :]

        batch_agent1_s = torch.FloatTensor(batch_transi[:, :self.agent1_s_dim])
        batch_agent1_a = torch.FloatTensor(batch_transi[:, self.agent1_s_dim:self.agent1_s_dim + self.agent1_a_dim])
        batch_agent1_r = torch.FloatTensor(batch_transi[:, self.agent1_s_dim + self.agent1_a_dim:self.agent1_s_dim + self.agent1_a_dim+1])
        batch_agent1_s_ = torch.FloatTensor(batch_transi[:, self.agent1_s_dim + self.agent1_a_dim+1:self.agent1_s_dim*2 + self.agent1_a_dim+1])

        batch_agent2_s = torch.FloatTensor(batch_transi[:, self.agent1_s_dim*2 + self.agent1_a_dim+1:self.agent1_s_dim*2 + self.agent1_a_dim+1+self.agent2_s_dim])
        batch_agent2_a = torch.FloatTensor(batch_transi[:, self.agent1_s_dim*2 + self.agent1_a_dim+1+self.agent2_s_dim:self.agent1_s_dim*2 + self.agent1_a_dim+1+self.agent2_s_dim+self.agent2_a_dim])
        batch_agent2_r = torch.FloatTensor(batch_transi[:, self.agent1_s_dim*2 + self.agent1_a_dim+1+self.agent2_s_dim+self.agent2_a_dim:self.agent1_s_dim*2 + self.agent1_a_dim+2+self.agent2_s_dim+self.agent2_a_dim])
        batch_agent2_s_ = torch.FloatTensor(batch_transi[:, -self.agent2_s_dim:])
        
        """
        for agent1
        """
        self.agent1_critic_optim.zero_grad()

        batch_actions = torch.cat([batch_agent1_a, batch_agent2_a], dim=1)   
        
        if self.discrete_action1:   
            agent1_a_target = misc.onehot_from_logits(self.agent1_actor_target_network(batch_agent1_s_))   
        else:                     
            agent1_a_target = self.agent1_actor_target_network(batch_agent1_s_)
        
        if self.discrete_action2:    
            agent2_a_target = misc.onehot_from_logits(self.agent2_actor_target_network(batch_agent2_s_))    
        else:                     
            agent2_a_target = self.agent2_actor_target_network(batch_agent2_s_)
        
        a_targets = torch.cat([agent1_a_target, agent2_a_target], dim=1)

        agent1_q_tmp = self.agent1_critic_target_network(batch_agent1_s_, a_targets)
        agent1_q_target = batch_agent1_r + self.GAMMA * agent1_q_tmp

        agent1_q_eval = self.agent1_critic_network(batch_agent1_s, batch_actions)
        agent1_td_error = self.loss_func(agent1_q_eval, agent1_q_target.detach())

        self.agent1writer.add_scalar('Loss/critic_loss', agent1_td_error, global_step=self.num_critic_update_iteration)

        agent1_td_error.backward()
        torch.nn.utils.clip_grad_norm_(self.agent1_critic_network.parameters(), 0.5)  
        self.agent1_critic_optim.step()

       
        self.agent1_actor_optim.zero_grad()

       
        if self.discrete_action1:   
            agent1_pol_out = self.agent1_actor_network(batch_agent1_s)   
            agent1_pol_a_vf = misc.gumbel_softmax(agent1_pol_out, hard=True)   
        else:      
            agent1_pol_out = self.agent1_actor_network(batch_agent1_s)   
            agent1_pol_a_vf = agent1_pol_out   
        
        if self.discrete_action2:   
            agent2_pol_out = self.agent2_actor_network(batch_agent2_s)  
            agent2_pol_a_vf = misc.gumbel_softmax(agent2_pol_out, hard=True)  
        else:     
            agent2_pol_out = self.agent2_actor_network(batch_agent2_s)   
            agent2_pol_a_vf = agent2_pol_out   
        
       
        if self.discrete_action2:
            agent2_aa = misc.onehot_from_logits(agent2_pol_out)
        else:
            agent2_aa = agent2_pol_out
        agent1_all_pol = torch.cat((agent1_pol_a_vf, agent2_aa), dim=1)
        
        agent1_pol_loss = -self.agent1_critic_network(batch_agent1_s, agent1_all_pol).mean()
        agent1_pol_loss += (agent1_pol_out**2).mean() * 1e-3

        self.agent1writer.add_scalar('Loss/actor_loss', agent1_pol_loss, global_step=self.num_actor_update_iteration)

        agent1_pol_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.agent1_actor_network.parameters(), 0.5)
        self.agent1_actor_optim.step()

        """
        for agent2
        """

        self.agent2_critic_optim.zero_grad()

        batch_actions = torch.cat([batch_agent1_a, batch_agent2_a], dim=1)   
      
        if self.discrete_action1:    
            agent1_a_target = misc.onehot_from_logits(self.agent1_actor_target_network(batch_agent1_s_))  
        else:                     
            agent1_a_target = self.agent1_actor_target_network(batch_agent1_s_)
        
        if self.discrete_action2:   
            agent2_a_target = misc.onehot_from_logits(self.agent2_actor_target_network(batch_agent2_s_))    
        else:                     
            agent2_a_target = self.agent2_actor_target_network(batch_agent2_s_)
        
        a_targets = torch.cat([agent1_a_target, agent2_a_target], dim=1)

        
        agent2_q_tmp = self.agent2_critic_target_network(batch_agent2_s_, a_targets)
        agent2_q_target = batch_agent2_r + self.GAMMA * agent2_q_tmp

        agent2_q_eval = self.agent2_critic_network(batch_agent2_s, batch_actions)
        agent2_td_error = self.loss_func(agent2_q_eval, agent2_q_target.detach())

        self.agent2writer.add_scalar('Loss/critic_loss', agent2_td_error, global_step=self.num_critic_update_iteration)

        agent2_td_error.backward()
        torch.nn.utils.clip_grad_norm_(self.agent2_critic_network.parameters(), 0.5) 
        self.agent2_critic_optim.step()

        
        self.agent2_actor_optim.zero_grad()

        if self.discrete_action1:  
            agent1_pol_out = self.agent1_actor_network(batch_agent1_s)  
            agent1_pol_a_vf = misc.gumbel_softmax(agent1_pol_out, hard=True)   
        else:      
            agent1_pol_out = self.agent1_actor_network(batch_agent1_s)   
            agent1_pol_a_vf = agent1_pol_out    
        
        if self.discrete_action2:    
            agent2_pol_out = self.agent2_actor_network(batch_agent2_s)   
            agent2_pol_a_vf = misc.gumbel_softmax(agent2_pol_out, hard=True)   
        else:      
            agent2_pol_out = self.agent2_actor_network(batch_agent2_s)  
            agent2_pol_a_vf = agent2_pol_out    

        if self.discrete_action1:
            agent1_aa = misc.onehot_from_logits(agent1_pol_out)
        else:
            agent1_aa = agent1_pol_out
        agent2_all_pol = torch.cat((agent1_aa, agent2_pol_a_vf), dim=1)
        
        agent2_pol_loss = -self.agent2_critic_network(batch_agent2_s, agent2_all_pol).mean()
        agent2_pol_loss += (agent2_pol_out**2).mean() * 1e-3

        self.agent2writer.add_scalar('Loss/actor_loss', agent2_pol_loss, global_step=self.num_actor_update_iteration)

        agent2_pol_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.agent2_actor_network.parameters(), 0.5)
        self.agent2_actor_optim.step()

        
        for x in self.agent1_actor_target_network.state_dict().keys():
            eval('self.agent1_actor_target_network.' + x + '.data.mul_((1-self.TAU))')
            eval('self.agent1_actor_target_network.' + x + '.data.add_(self.TAU*self.agent1_actor_network.' + x + '.data)')
        for x in self.agent1_critic_target_network.state_dict().keys():
            eval('self.agent1_critic_target_network.' + x + '.data.mul_((1-self.TAU))')
            eval('self.agent1_critic_target_network.' + x + '.data.add_(self.TAU*self.agent1_critic_network.' + x + '.data)')
        
        for x in self.agent2_actor_target_network.state_dict().keys():
            eval('self.agent2_actor_target_network.' + x + '.data.mul_((1-self.TAU))')
            eval('self.agent2_actor_target_network.' + x + '.data.add_(self.TAU*self.agent2_actor_network.' + x + '.data)')
        for x in self.agent2_critic_target_network.state_dict().keys():
            eval('self.agent2_critic_target_network.' + x + '.data.mul_((1-self.TAU))')
            eval('self.agent2_critic_target_network.' + x + '.data.add_(self.TAU*self.agent2_critic_network.' + x + '.data)')
        
        self.num_actor_update_iteration += 1
        self.num_critic_update_iteration += 1
    

    def save(self):
        torch.save(self.agent1_actor_network.state_dict(), self.agent1directory + 'actor.pth')
        torch.save(self.agent1_critic_network.state_dict(), self.agent1directory + 'critic.pth')
        torch.save(self.agent2_actor_network.state_dict(), self.agent2directory + 'actor.pth')
        torch.save(self.agent2_critic_network.state_dict(), self.agent2directory + 'critic.pth')
        # print("====================================")
        # print("Model has been saved...")
        # print("====================================")

    def load(self):
        self.agent1_actor_network.load_state_dict(torch.load(self.agent1directory + 'actor.pth'))
        self.agent1_critic_network.load_state_dict(torch.load(self.agent1directory + 'critic.pth'))
        self.agent2_actor_network.load_state_dict(torch.load(self.agent2directory + 'actor.pth'))
        self.agent2_critic_network.load_state_dict(torch.load(self.agent2directory + 'critic.pth'))
        print("====================================")
        print("model has been loaded...")
        print("====================================")

def Gnoise(T, CAPACITY, agent_a_dim):
    
    if T <= CAPACITY:
        xigema = 1
    elif T > CAPACITY:
        xigema = max(pow(0.999, T-CAPACITY) , 0.02)
    noise = np.random.normal(0, xigema, size=(agent_a_dim))   
    
    return noise

########################## CB environment (MADDPG, discrete action)######################
class EnvCB(object):
    
    state_dim = 127   
    action_dim = 16    
    action_bound = [0, 15]  

    Para = branchflowDDPG.Parameter("data/123nodedata2.xlsx") 
    tool = branchflowDDPG.Excel_tool()

    def __init__(self):
        super(EnvCB, self).__init__()
        
        self.P = np.zeros((123, 6),dtype= np.float32)        
        self.averageP = np.zeros((123, 1),dtype= np.float32)
    
    def reset(self, mm):
        T = mm
        for t in range(6):
            for n in range(self.Para.N_bus):
                self.P[n,t] = self.Para.Bus[n, 1] * self.Para.Day[6*T + t, 1]
                if n in self.Para.Gen[:, 1]:  
                    i = int(np.where(n == self.Para.Gen[:, 1])[0])  
                    self.P[i,t] -= self.Para.Gen[i, 2] * self.Para.Day[6*T + t, (int(self.Para.Gen[i, 3]) + 2)] * math.cos(self.Para.Factor)  
        self.averageP = np.mean(self.P, axis=1)
        self.averageP = self.averageP.reshape((123,1))     
        return self.averageP     

########################## OLTC environment (MADDPG, discrete action)######################
class EnvOLTC(object):
   
    state_dim = 124   
    action_dim = 17   
    action_bound = [0, 16]    

########################## PV environment (MADDPG, continuous aciton)######################
class EnvPV(object):
   
    state_dim = 123    
    action_dim = 12    
    action_bound = [-1, 1]   

    Para = branchflowDDPG.Parameter("data/123nodedata2.xlsx")  
    tool = branchflowDDPG.Excel_tool()

    def __init__(self):
        super(EnvPV, self).__init__()
        
        self.voltage = np.zeros((123, 1),dtype= np.float32)  
    
    def reset(self, OT, AT, mm):     
        done = False        
        t = mm
        para = copy.deepcopy(self.Para)
        for n in range(para.N_bus):
            if n in para.CBs[:, 1]:
                i = int(np.where(n == para.CBs[:, 1])[0])
                para.Bus[n, 2] -= AT[i, 0] * para.CBs[i, 2]/para.Day[t,1]    
        
        sol = branchflowDDPG.main_function(para, t, OT)

        self.voltage = sol   
        assert (self.voltage.shape == (123, 1))
        done = True
        return  self.voltage, done  
    
    def step(self, action, OT, AT, ST, mm):   
        done = False        
        T = mm
        r = 0.               
        action = np.clip(action, *self.action_bound)  
        para = copy.deepcopy(self.Para)    
        for n in range(para.N_bus):
            if n in para.CBs[:, 1]:
                i = int(np.where(n == para.CBs[:, 1])[0])
                para.Bus[n, 2] -= AT[i, 0] * para.CBs[i, 2]/para.Day[T,1]  
            if n in para.Gen[:, 1]:
                i = int(np.where(n == para.Gen[:, 1])[0])
                para.Bus[n, 2] -= action[i, 0] * 0.31 * para.Gen[i, 2]/para.Day[T,1]   
            if n in para.Store[:,1]:
                i = int(np.where(n == para.Store[:, 1])[0])
                para.Bus[n, 1] += ST[i, 0] * para.Store[i, 4]/para.Day[T,1]     
        
        sol = branchflowDDPG.main_function(para, T, OT)

        self.voltage = sol   
        assert (self.voltage.shape == (123, 1))

        for i in range(123):
            r -= (self.voltage[i, 0] - 1)**2   
        done = True
        return  self.voltage, r, done   

########################## Store environment (MADDPG, continuous action)######################
class EnvStore(object):
    
    state_dim = 135   
    action_dim = 4    
    action_bound = [-1, 1]   

############################### Training ######################################
def main():
   
    episodes = 48       
    EPISODES = 288       
    Nt = 6
   
    test_EPISODES = 288     
    test_episodes = 48

    OLTCenv = EnvOLTC()
    s_dim_OLTC = OLTCenv.state_dim     
    a_dim_OLTC = OLTCenv.action_dim    

    CBenv = EnvCB()
    s_dim_CB = CBenv.state_dim     
    a_dim_CB = CBenv.action_dim    

    maddpg_O_C = MADDPG(a_dim_OLTC, s_dim_OLTC,  a_dim_CB, s_dim_CB, 0.001, 0.001, 0.99, 0.005, 50, 10, 'OLTC1051', 'CBs1051', discrete_action1=True, discrete_action2=True,)

    Storeenv = EnvStore()
    s_dim_Store = Storeenv.state_dim    
    a_dim_Store = Storeenv.action_dim   

    PVenv = EnvPV()
    s_dim_PV = PVenv.state_dim    
    a_dim_PV = PVenv.action_dim   

    maddpg_S_P = MADDPG(a_dim_Store, s_dim_Store,  a_dim_PV, s_dim_PV, 0.001, 0.001, 0.99, 0.005, 1000, 64,'Store1051', 'PV1051', discrete_action1=False, discrete_action2=False)

    Para = branchflowDDPG.Parameter("data/123nodedata2.xlsx") 
    Emin = Para.Store[:,2]     
    Emax = Para.Store[:,3]      
    Pmax = Para.Store[:,4]      

    mode = 'test'

    if mode == 'train':
        EP_STEPS = 300

        ep_r_OLTC = np.zeros((episodes,EP_STEPS))
        ep_r_CB = np.zeros((episodes,EP_STEPS))
        ep_r_Store = np.zeros((EPISODES, EP_STEPS))
        ep_r_PV = np.zeros((EPISODES, EP_STEPS))
        reward_OLTC = np.zeros((1,EP_STEPS))
        reward_CB = np.zeros((1,EP_STEPS))
        reward_PV = np.zeros((1,EP_STEPS))
        reward_Store = np.zeros((1,EP_STEPS))

        VOLTAGE = np.zeros((123, EPISODES, EP_STEPS))   
        
        t1 = time.time()

        for h in range(EP_STEPS):
            day = np.random.randint(0,10)   
            begin = 288*day

            state_OLTC = np.zeros((s_dim_OLTC, 1))
            state_OLTC_ = np.zeros((s_dim_OLTC, 1))

            state_CB = np.zeros((s_dim_CB,1))    
            state_CB_ = np.zeros((s_dim_CB,1))    

            Enow = np.zeros((a_dim_Store,1))    
            state_Store = np.zeros((s_dim_Store, 1))  
            state_Store_ = np.zeros((s_dim_Store, 1))  

            state_PV = np.zeros((s_dim_PV, 1))
            state_PV_ = np.zeros((s_dim_PV, 1))

            OLTCtap = 0    

            CBaction4 = np.zeros((4,1))     
            CBaction = 0       
            
            state_averageP0 = CBenv.reset(48*day)
            for i in range(123):
                state_CB[i,0] = state_averageP0[i,0]
            for i in range(123, 127):
                state_CB[i,0] = CBaction4[i-123,0] 
            sstate_CB = state_CB.ravel()      
            
            for i in range(123):
                state_OLTC[i,0] = state_averageP0[i,0]
            state_OLTC[123,0] = OLTCtap
            sstate_OLTC = state_OLTC.ravel()   

            for i in range(4):        
                Enow[i,0] = 0.5 * Emax[i]    
            
            
            for i in range(127,131):        
                state_Store[i,0] = Emin[i-127]
                state_Store_[i,0] = Emin[i-127]       
            for i in range(131,135):        
                state_Store[i,0] = Emax[i-131]
                state_Store_[i,0] = Emax[i-131]


            for T in range(episodes-1):

                OLTCAction, CBAction = maddpg_O_C.choose_action(sstate_OLTC, sstate_CB, explore=True)
                
                OLTCaction = torch.max(OLTCAction, -1)[1].data.numpy()   
                CBaction = torch.max(CBAction, -1)[1].data.numpy()      

                OLTCtap = OLTCaction - 8       

                CBaction1 = "{0:b}".format(CBaction).zfill(4)   
                CBaction2 = [ int(x) for x in CBaction1 ]  
                CBaction3 = np.array(CBaction2)          
                CBaction4 = CBaction3.reshape(4,1)     

                for t in range(Nt):
                   
                    j = Nt*T+t
                    jj = j+begin
                    
                    voltage, done = PVenv.reset(OLTCtap, CBaction4, jj)     

                    for i in range(123):
                        state_PV[i, 0] = voltage[i, 0]
                        state_Store[i, 0] = voltage[i, 0]
                    for i in range(123, 127):
                        state_Store[i, 0] = Enow[i-123]
                    sstate_PV = state_PV.ravel()   
                    sstate_Store = state_Store.ravel()    

                    Storeaction, PVaction = maddpg_S_P.choose_action(sstate_Store, sstate_PV, explore=True)
                    
                    Storeact = Storeaction.numpy()  
                    PVact = PVaction.numpy()
                    Storeaction1 = Storeact.reshape(a_dim_Store, 1)  
                    PVaction1 = PVact.reshape(a_dim_PV, 1)     

                    for i in range(a_dim_Store):
                        if Storeaction1[i, 0] >= 0:     
                            if (Storeaction1[i,0]*Pmax[i]) >= (Emax[i]-Enow[i,0]):
                                Storeaction1[i,0] = (Emax[i]-Enow[i,0])/Pmax[i]
                                Enow[i,0] = Emax[i]
                            else:
                                Enow[i,0] = Enow[i,0] + Storeaction1[i,0]*Pmax[i]
                        elif Storeaction1[i,0] < 0:
                            if (Storeaction1[i,0]*Pmax[i]) <= (Emin[i]-Enow[i,0]):
                                Storeaction1[i,0] = (Emin[i]-Enow[i,0])/Pmax[i]
                                Enow[i,0] = Emin[i]
                            else:
                                Enow[i,0] = Enow[i,0] + Storeaction1[i,0]*Pmax[i]
                    Storeaction2 = Storeaction1.ravel()    
                    
                    state_PV_, r_PV, done = PVenv.step(PVaction1, OLTCtap, CBaction4, Storeaction1, jj)
                    sstate_PV_ = state_PV_.ravel()     

                    for i in range(123):
                        state_Store_[i,0] = state_PV_[i,0]
                    for i in range(123, 127):
                        state_Store_[i,0] = Enow[i-123]
                    r_Store = r_PV
                    sstate_Store_ = state_Store_.ravel()     

                    maddpg_S_P.store_transition(sstate_Store, Storeaction2, r_Store, sstate_Store_, sstate_PV, PVact, r_PV, sstate_PV_)

                    if maddpg_S_P.pointers > maddpg_S_P.MEMORY_CAPACITY:
                        maddpg_S_P.learn()
                    
                    ep_r_PV[j, h] = r_PV
                    reward_PV[0, h] += r_PV
                    ep_r_Store[j, h] = r_Store
                    reward_Store[0, h] += r_Store

                    ep_r_CB[T, h] += r_PV
                    ep_r_OLTC[T, h] += r_PV

                    VOLTAGE[:, j, h] = sstate_PV_
                
                state_averageP0 = CBenv.reset(T+1+48*day)   
                
                for i in range(123):
                    state_CB_[i,0] = state_averageP0[i,0]
                    state_OLTC_[i,0] = state_averageP0[i,0]
                for i in range(123, 127):
                    state_CB_[i,0] = CBaction4[i-123, 0]
                state_OLTC_[123, 0] = OLTCtap

                sstate_CB_ = state_CB_.ravel()    
                sstate_OLTC_ = state_OLTC_.ravel()    

                OLTCAct = OLTCAction.numpy()     
                CBAct = CBAction.numpy()

                maddpg_O_C.store_transition(sstate_OLTC, OLTCAct, ep_r_OLTC[T, h], sstate_OLTC_, sstate_CB, CBAct, ep_r_CB[T, h], sstate_CB_)

                if maddpg_O_C.pointers >= maddpg_O_C.MEMORY_CAPACITY:
                    maddpg_O_C.learn()
                
                reward_OLTC[0,h] += ep_r_OLTC[T, h]
                reward_CB[0,h] += ep_r_CB[T, h]

                state_OLTC = state_OLTC_
                sstate_OLTC = sstate_OLTC_
                state_CB = state_CB_
                sstate_CB = sstate_CB_

            
            maddpg_O_C.save()
            maddpg_S_P.save()
            name = 'MADDPGnew1053.mat'
            sio.savemat(name,{'vol_train':VOLTAGE, 'rewardOLTC':reward_OLTC, 'rewardCB':reward_CB, 'rewardPV':reward_PV,'rewardStore':reward_Store})
        
        print('Running time: ', time.time() - t1)
        name = 'MADDPGnew1053.mat'
        sio.savemat(name,{'vol_train':VOLTAGE, 'rewardOLTC':reward_OLTC, 'rewardCB':reward_CB, 'rewardPV':reward_PV,'rewardStore':reward_Store})

    elif mode == 'test':
        maddpg_O_C.load()
        maddpg_S_P.load()

        ep_r_OLTC = np.zeros((test_episodes,1))
        ep_r_CB = np.zeros((test_episodes,1))
        ep_r_PV = np.zeros((test_EPISODES,1))
        ep_r_Store = np.zeros((test_EPISODES,1))
        rewardsum = np.zeros((1,1))

        voltage_test = np.zeros((123,test_EPISODES))

        state_OLTC = np.zeros((s_dim_OLTC, 1))
        state_OLTC_ = np.zeros((s_dim_OLTC, 1))

        state_CB = np.zeros((s_dim_CB,1))     
        state_CB_ = np.zeros((s_dim_CB,1))    

        Enow = np.zeros((a_dim_Store,1))     
        state_Store = np.zeros((s_dim_Store, 1))  
        state_Store_ = np.zeros((s_dim_Store, 1))   

        state_PV = np.zeros((s_dim_PV, 1))
        state_PV_ = np.zeros((s_dim_PV, 1))

        action_OLTC = np.zeros((1, test_episodes))
        action_CB = np.zeros((4, test_episodes))

        OLTCtap = 0   

        CBaction4 = np.zeros((4,1))   
        CBaction = 0       

        for i in range(4):        
            Enow[i,0] = 0.5 * Emax[i]    
        
        for i in range(127,131):        
            state_Store[i,0] = Emin[i-127]
            state_Store_[i,0] = Emin[i-127]       
        for i in range(131,135):       
            state_Store[i,0] = Emax[i-131]
            state_Store_[i,0] = Emax[i-131]

        TTN = np.zeros((test_EPISODES,1))
        ttn = np.zeros((test_episodes,1))
        
        t2 = time.time()

        for T in range(test_episodes):
            
            state_averageP0 = CBenv.reset(episodes*10+T)
   
            for i in range(123):
                state_CB[i,0] = state_averageP0[i,0]
                state_OLTC[i,0] = state_averageP0[i,0]
            for i in range(123, 127):
                state_CB[i,0] = CBaction4[i-123,0] 
            sstate_CB = state_CB.ravel()     
                
            state_OLTC[123,0] = OLTCtap
            sstate_OLTC = state_OLTC.ravel()    

            t3 = time.time()
            
            OLTCAction, CBAction = maddpg_O_C.choose_action(sstate_OLTC, sstate_CB, explore=False)
            
            OLTCaction = torch.max(OLTCAction, -1)[1].data.numpy()    
            CBaction = torch.max(CBAction, -1)[1].data.numpy()      

            ttn[T, 0] = time.time() - t3

            OLTCtap = OLTCaction - 8

            CBaction1 = "{0:b}".format(CBaction).zfill(4)   
            CBaction2 = [ int(x) for x in CBaction1 ]  
            CBaction3 = np.array(CBaction2)          
            CBaction4 = CBaction3.reshape(4,1)     
           
            action_OLTC[0, T] = OLTCtap
            action_CB[:, T] = CBaction3

            for t in range(Nt):
                j = Nt*T+t
                
                
                voltage, done = PVenv.reset(OLTCtap, CBaction4, j+2880)    

                for i in range(123):
                    state_PV[i, 0] = voltage[i, 0]
                    state_Store[i, 0] = voltage[i, 0]
                for i in range(123, 127):
                    state_Store[i, 0] = Enow[i-123]
                sstate_PV = state_PV.ravel()     
                sstate_Store = state_Store.ravel()    

                t4 = time.time()
                Storeaction, PVaction = maddpg_S_P.choose_action(sstate_Store, sstate_PV, explore=False)
               
                Storeact = Storeaction.numpy() 
                PVact = PVaction.numpy()
                Storeaction1 = Storeact.reshape(a_dim_Store, 1)  
                PVaction1 = PVact.reshape(a_dim_PV, 1)    

                
                for i in range(a_dim_Store):
                    if Storeaction1[i, 0] >= 0:      
                        if (Storeaction1[i,0]*Pmax[i]) >= (Emax[i]-Enow[i,0]):
                            Storeaction1[i,0] = (Emax[i]-Enow[i,0])/Pmax[i]
                            Enow[i,0] = Emax[i]
                        else:
                            Enow[i,0] = Enow[i,0] + Storeaction1[i,0]*Pmax[i]
                    elif Storeaction1[i,0] < 0:
                        if (Storeaction1[i,0]*Pmax[i]) <= (Emin[i]-Enow[i,0]):
                            Storeaction1[i,0] = (Emin[i]-Enow[i,0])/Pmax[i]
                            Enow[i,0] = Emin[i]
                        else:
                            Enow[i,0] = Enow[i,0] + Storeaction1[i,0]*Pmax[i]
                Storeaction2 = Storeaction1.ravel()   

                TTN[j, 0] = time.time() - t4
                
                state_PV_, r_PV, done = PVenv.step(PVaction1, OLTCtap, CBaction4, Storeaction1, j+2880)
                sstate_PV_ = state_PV_.ravel()     

                ep_r_PV[j,0] = r_PV
                ep_r_Store[j,0] = r_PV
                ep_r_CB[T, 0] += r_PV
                ep_r_OLTC[T, 0] += r_PV
                rewardsum += r_PV

                voltage_test[:,j] = sstate_PV_
        
        Time = np.sum(ttn, axis=0) + np.sum(TTN, axis=0)
        print('Time:', Time)
        print('Running time: ', time.time() - t2)
        name = 'MADDPGnewtest1051clear.mat'
        sio.savemat(name,{'vol_test':voltage_test, 'rOLTC':ep_r_OLTC, 'rCB':ep_r_CB, 'rPV':ep_r_PV,'rStore':ep_r_Store,'rsum':rewardsum, 'actionOLTC':action_OLTC, 'actionCB':action_CB})


if __name__ == '__main__':
    main()
