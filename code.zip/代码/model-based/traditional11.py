import math
import numpy as np
import gurobipy as gp
import openpyxl as pyxl
import matplotlib.pyplot as plt
import scipy.io as sio         

import copy
import time

class Parameter(object):

    # Initialization
    def __init__(self, filename):
        # 1. System Data
        tool = Excel_tool()
        data = tool.read_excel(filename)
        # 1) line
        self.Line = data[0]          
        self.N_line = len(self.Line)  
        # 2) bus
        self.Bus = data[1]          
        self.N_bus = len(self.Bus)  
        # 3) substation
        self.Sub = data[2]          
        self.N_sub = len(self.Sub)  
        # 4) generator
        self.Gen = data[3]          
        self.N_gen = len(self.Gen)  
        self.Factor = 0.31756  
        # 5) daily curve
        self.Day = data[4]
        self.N_time = len(self.Day)  
        # 6) CBs
        self.CBs = data[5]     
        self.N_CBs = len(self.CBs)   
        # 7) Store
        self.Store = data[6]   
        self.N_store = len(self.Store) 
        
        self.var_index()          

        # Base value
        self.Base_V = 4.16  
        self.Base_S = 100.00  
        self.Base_Z = self.Base_V ** 2 / self.Base_S  
        self.Base_I = self.Base_S / self.Base_V / np.sqrt(3)  
        

        # Other
        self.Big_M = 1e2  
        self.V_min = 0.95 ** 2
        self.V_max = 1.05 ** 2

        self.Line_head = [[] for i in range(self.N_bus)]
        self.Line_tail = [[] for i in range(self.N_bus)]
        for i in range(self.N_line):
            head = self.Line[i][1]
            tail = self.Line[i][2]
            self.Line_head[int(round(head))].append(i)
            self.Line_tail[int(round(tail))].append(i)


    def var_index(self):
        global NT, nt
        NT = 24  
        nt = NT * 6
        # 1. Name
        global N_V_bus, N_I_line, N_P_line, N_Q_line
        global N_P_sub, N_Q_sub, N_Q_CB, N_TAP_OLTC, N_Q_PV, N_P_STORE, N_E_STORE, N_N_var
        # 2. Initialization
        N_V_bus = 0 
        N_I_line = N_V_bus + self.N_bus  
        N_P_line = N_I_line + self.N_line  
        N_Q_line = N_P_line + self.N_line 
        N_P_sub = N_Q_line + self.N_line
        N_Q_sub = N_P_sub + self.N_sub
        N_Q_PV = N_Q_sub + self.N_sub       
        N_P_STORE = N_Q_PV + self.N_gen     
        N_E_STORE = N_P_STORE + self.N_store    
        N_N_var =  N_E_STORE + self.N_store  
        
        N_TAP_OLTC = 0   
        N_Q_CB = 0     


# This class creates the execution tool for Excel files 
# -----------------------------------------------------------------------------
#
class Excel_tool(object):

    # Initialization
    def __init__(self):
        pass

    def read_excel(self, filename):
        data = []
        book = pyxl.load_workbook(filename)    
        
        for i, name in enumerate(book.sheetnames):  
            if i < len(book.sheetnames):
                sheet = book[name]
                n_row = sheet.max_row 
                n_col = sheet.max_column  
                data.append(self.tool_filter(sheet, n_row, n_col))
        return data

    def save_excel(self, filename, sheetname, title, data):
        book = pyxl.load_workbook(filename)
        name = book.sheetnames[-1]
        book.remove(book[name])
        sheet = book.create_sheet(sheetname)
        sheet.append(title)
        for i in range(len(data)):
            sheet.append(data[i, :].tolist())  
        book.save(filename=filename)

    def tool_filter(self, sheet, n_row, n_col):
        k = 0
        data = []
        for i in range(n_row):
            if sheet['A' + str(i + 1)].data_type == 'n': 
                data.append([])
                for j in range(n_col):
                    pos = chr(64 + j + 1) + str(i + 1)  
                    val = sheet[pos].value
                    if sheet[pos].data_type == 'n':
                        data[k].append(val)
                k = k + 1
        return np.array(data)


# This function defines the operation model
# -----------------------------------------------------------------------------
#
def DistFlow_Model(model, Para, v_flow, hour, obj):
    # Objective obj
    opr = gp.QuadExpr()     
    for j in range(nt):
        for n in range(Para.N_bus):
            ep_0 = v_flow[N_V_bus + n, j] - 1      
            ep_1 = ep_0 * ep_0
            opr = opr + ep_1
    model.addConstr(obj[0] >= opr)


    m = sio.loadmat("traditional6.mat")
    OLTCcon = m["v_tap"]      
    CBscon = m["v_CB"]      

    # Constraint
    # 1. Nodal active power balance 
    for j in range(nt):            
        for n in range(Para.N_bus):
        # Bus-Line information
            line_head = Para.Line_head[n]
            line_tail = Para.Line_tail[n]
            # Formulate expression 
            expr = gp.LinExpr()
            expr = expr - gp.quicksum(v_flow[N_P_line + i, j] for i in line_head)
            expr = expr + gp.quicksum(v_flow[N_P_line + i, j] for i in line_tail)
            for i in line_tail:      
                expr = expr - v_flow[N_I_line + i, j] * Para.Line[i, 4]
            if n in Para.Sub[:, 1]:  
                i = int(np.where(n == Para.Sub[:, 1])[0])
                expr = expr + v_flow[N_P_sub + i, j]
            if n in Para.Gen[:, 1]: 
                i = int(np.where(n == Para.Gen[:, 1])[0])  
                expr = expr + Para.Gen[i, 2] * Para.Day[hour+j, (int(Para.Gen[i, 3]) + 2)]* math.cos(Para.Factor)    
           
            if n in Para.Store[:, 1]:    
                i = int(np.where(n == Para.Store[:, 1])[0])
                expr = expr - v_flow[N_P_STORE + i, j]
            model.addConstr(expr == Para.Bus[n, 1] * Para.Day[hour+j, 1])   

    # 2. Nodal reactive power balance  
    for T in range(NT): 
        for t in range(6):
            j = T*6+t
            for n in range(Para.N_bus):
                # Bus-Line information
                line_head = Para.Line_head[n]
                line_tail = Para.Line_tail[n]
                # Formulate expression
                expr = gp.LinExpr()
                expr = expr - gp.quicksum(v_flow[N_Q_line + i, j] for i in line_head)
                expr = expr + gp.quicksum(v_flow[N_Q_line + i, j] for i in line_tail)
                for i in line_tail:
                    expr = expr - v_flow[N_I_line + i, j] * Para.Line[i, 5]
                if n in Para.Sub[:, 1]:  
                    i = int(np.where(n == Para.Sub[:, 1])[0])
                    expr = expr + v_flow[N_Q_sub + i, j]
                if n in Para.Gen[:, 1]:  
                    i = int(np.where(n == Para.Gen[:, 1])[0])
                    expr = expr + v_flow[N_Q_PV + i, j]           
                if n in Para.CBs[:, 1]:
                    i = int(np.where(n == Para.CBs[:, 1])[0])
                    expr = expr + CBscon[N_Q_CB + i, T] * Para.CBs[i, 2]
                model.addConstr(expr == Para.Bus[n, 2] * Para.Day[hour+j, 1])    
        
    # 3. Branch flow equation    
    for j in range(nt): 
        for n in range(Para.N_line):
            bus_head = Para.Line[n, 1]
            bus_tail = Para.Line[n, 2]
            # Formulate expression
            expr = gp.LinExpr()
            expr = expr + v_flow[N_V_bus + bus_head, j] - v_flow[N_V_bus + bus_tail, j]
            expr = expr - v_flow[N_P_line + n, j] * Para.Line[n, 4] * 2
            expr = expr - v_flow[N_Q_line + n, j] * Para.Line[n, 5] * 2
            expr = expr + v_flow[N_I_line + n, j] * (Para.Line[n, 4] ** 2)
            expr = expr + v_flow[N_I_line + n, j] * (Para.Line[n, 5] ** 2)
            model.addConstr(expr == 0)    
    
    # 4. Second order conic constraint 
    for j in range(nt): 
        for n in range(Para.N_line):
            ep_0 = v_flow[N_P_line + n, j] * 2
            ep_1 = v_flow[N_Q_line + n, j] * 2
            ep_2 = v_flow[N_I_line + n, j] - v_flow[N_V_bus + Para.Line[n, 1], j]
            ep_3 = v_flow[N_I_line + n, j] + v_flow[N_V_bus + Para.Line[n, 1], j]
            model.addConstr(ep_0 * ep_0 + ep_1 * ep_1 + ep_2 * ep_2 <= ep_3 * ep_3)  
    

    # 6. Lower and Upper bound  
    for j in range(nt): 
        # 1) voltage amplitutde  
        for n in range(Para.N_bus):
            model.addConstr(v_flow[N_V_bus + n, j] >= Para.V_min)
            model.addConstr(v_flow[N_V_bus + n, j] <= Para.V_max)
        # 2) line current  
        for n in range(Para.N_line):
            Imax = 0.1
            model.addConstr(v_flow[N_I_line + n, j] >= 0)
            model.addConstr(v_flow[N_I_line + n, j] <= Imax)
        # 4) substation
        for n in range(Para.N_sub):
            smax = Para.Sub[n, 2]
            model.addConstr(v_flow[N_P_sub + n, j] >= -smax)
            model.addConstr(v_flow[N_P_sub + n, j] <= smax)
            model.addConstr(v_flow[N_Q_sub + n, j] >= -smax)
            model.addConstr(v_flow[N_Q_sub + n, j] <= smax)
        # 5) renewables 
        for n in range(Para.N_gen):
            smax = 0.31 * Para.Gen[n, 2]   
            model.addConstr(v_flow[N_Q_PV + n, j] >= -smax)
            model.addConstr(v_flow[N_Q_PV + n, j] <= smax)
   

    for T in range(NT): 
        for t in range(6):
            j = T*6+t
            for n in range(Para.N_bus):
                if n in Para.Sub[:, 1]:   
                    i = int(np.where(n == Para.Sub[:, 1])[0])
                    model.addConstr(v_flow[N_V_bus + n, j] == (1.05 + OLTCcon[N_TAP_OLTC+i, T] * 0.0125) ** 2)
       
        
    for j in range(nt):
        for n in range(Para.N_store):
            
            Pmax = Para.Store[n, 4]
            model.addConstr(v_flow[N_P_STORE + n, j] >= -Pmax)
            model.addConstr(v_flow[N_P_STORE + n, j] <= Pmax)
            
            Emin = Para.Store[n, 2]
            Emax = Para.Store[n, 3]
            
            if (j == 0):
                model.addConstr(v_flow[N_P_STORE + n, j] + Emax/2 == v_flow[N_E_STORE + n, j])
            else:
                model.addConstr(v_flow[N_P_STORE + n, j] + v_flow[N_E_STORE + n, j-1] == v_flow[N_E_STORE + n, j])
            model.addConstr(v_flow[N_E_STORE + n, j] >= Emin)
            model.addConstr(v_flow[N_E_STORE + n, j] <= Emax)
        

    return model



# This class creates the Result class
# -----------------------------------------------------------------------------
#
class Result(object):

    # Initialization
    def __init__(self):
        pass

    # Obtain the value of variables
    def get_value(self, model, var, var_type):
        # Get value
        key = var.keys()
        val = var.copy()
        for i in range(len(key)):
            val[key[i]] = var[key[i]].x
        # Calculate dimention
        if isinstance(max(key), tuple):  # multi dimention
            dim = tuple([item + 1 for item in max(key)])
        if isinstance(max(key), int):  # one   dimention
            dim = tuple([int(len(key)), 1])
        # Convert dictionary to numpy array
        arr = np.zeros(dim, dtype=var_type)
        if var_type == "int":
            for i in range(len(val)):
                arr[key[i]] = int(round(val[key[i]]))
        else:
            for i in range(len(val)):
                arr[key[i]] = round(val[key[i]], 4)
        return arr


# This function defines the branch flow model  
# -----------------------------------------------------------------------------
#
def main_function(Para, hour):
    # Initialization
    # Import gurobi model  
    model = gp.Model()

    v_flow = model.addVars(N_N_var, nt , lb=-1e2)

    obj = model.addVars(1)

    # Build Models
    # Build the model
    model = DistFlow_Model(model, Para, v_flow, hour, obj)

    # Objective
    model.setObjective(obj.sum('*'), gp.GRB.MINIMIZE)

    # Optimization
    model.optimize()
    if model.status == gp.GRB.Status.OPTIMAL or model.status == gp.GRB.Status.SUBOPTIMAL:    
        sol = Result()
        sol.v_flow = sol.get_value(model, v_flow, "float")
        sol.V_bus = sol.v_flow[N_V_bus: N_V_bus + Para.N_bus]
        sol.I_line = sol.v_flow[N_I_line: N_I_line + Para.N_line]
        sol.P_line = sol.v_flow[N_P_line: N_P_line + Para.N_line]
        sol.Q_line = sol.v_flow[N_Q_line: N_Q_line + Para.N_line]

        sol.P_sub = sol.v_flow[N_P_sub: N_P_sub + Para.N_sub]
        sol.Q_sub = sol.v_flow[N_Q_sub: N_Q_sub + Para.N_sub]
        sol.Q_PV = sol.v_flow[N_Q_PV: N_Q_PV + Para.N_gen]
        sol.P_STORE = sol.v_flow[N_P_STORE: N_P_STORE + Para.N_store]
        sol.E_STORE = sol.v_flow[N_E_STORE: N_E_STORE + Para.N_store]

    else:
        sol = -1


    return np.sqrt(sol.V_bus)



if __name__ == "__main__":

    Para = Parameter("data/123nodedata2.xlsx")
    tool = Excel_tool()

    t1 = time.time()
    V_bus = main_function(Para, 3024)
    print('Running time: ', time.time() - t1)

    name = 'traditional61.mat'
    sio.savemat(name,{'voltage':V_bus})

