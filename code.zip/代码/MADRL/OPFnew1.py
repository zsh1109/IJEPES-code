import math
import numpy as np
import gurobipy as gp
import openpyxl as pyxl
import matplotlib.pyplot as plt
import scipy.io as sio         


class Parameter(object):

    # Initialization
    def __init__(self, filename):
        # 1. System Data
        tool = Excel_tool()
        data = tool.read_excel(filename)
        # 1) line
        self.Line = data[0]          
        self.N_line = len(self.Line)  # number of line
        # 2) bus
        self.Bus = data[1]          
        self.N_bus = len(self.Bus)  # number of bus
        # 3) substation
        self.Sub = data[2]          
        self.N_sub = len(self.Sub)  # number of substation
        # 4) generator
        self.Gen = data[3]          
        self.N_gen = len(self.Gen)  # number of renewables
        self.Factor = 0.31756  # power factor (rad)
        # 5) daily curve
        self.Day = data[4]
        self.N_time = len(self.Day)  # number of hours
        # 6) CBs
        self.CBs = data[5]     
        self.N_CBs = len(self.CBs)   # number of CBs
        # 7) Store
        self.Store = data[6]   
        self.N_store = len(self.Store)  # number of Stores
        # 7) global variable index
        self.var_index()             

        # Base value
        self.Base_V = 4.16  # voltage
        self.Base_S = 100.00  # power
        self.Base_Z = self.Base_V ** 2 / self.Base_S  # impedance
        self.Base_I = self.Base_S / self.Base_V / np.sqrt(3)  # current


        # Other
        self.Big_M = 1e2  # a sufficient large number
        self.V_min = 0
        self.V_max = 10
       
        # Bus-Line Information
        self.Line_head = [[] for i in range(self.N_bus)]
        self.Line_tail = [[] for i in range(self.N_bus)]
        for i in range(self.N_line):
            head = self.Line[i][1]
            tail = self.Line[i][2]
            self.Line_head[int(round(head))].append(i)
            self.Line_tail[int(round(tail))].append(i)


 # This function creates global index  
    def var_index(self):

        # Real power flow   
        # 1. Name
        global N_V_bus, N_I_line, N_P_line, N_Q_line
        global N_P_sub, N_Q_sub, N_N_var
        # 2. Initialization
        N_V_bus = 0  # square of voltage amplitude  
        N_I_line = N_V_bus + self.N_bus  # square of voltage phase angle  
        N_P_line = N_I_line + self.N_line  # power flow (active)
        N_Q_line = N_P_line + self.N_line  # power flow (reactive)
        N_P_sub = N_Q_line + self.N_line
        N_Q_sub = N_P_sub + self.N_sub
        N_N_var = N_Q_sub + self.N_sub  # Number of all variables


# This class creates the execution tool for Excel files 
# -----------------------------------------------------------------------------
#
class Excel_tool(object):

    # Initialization
    def __init__(self):
        pass

    # inputs data from Excel file  
    def read_excel(self, filename):
        data = []
        book = pyxl.load_workbook(filename)     
        # Data preprocessing  
        for i, name in enumerate(book.sheetnames):  # sheet number
            if i < len(book.sheetnames):
                sheet = book[name]
                n_row = sheet.max_row # number of rows 
                n_col = sheet.max_column  # number of columns  
                data.append(self.tool_filter(sheet, n_row, n_col))
        return data

    # saving data to excel file 
    def save_excel(self, filename, sheetname, title, data):
        book = pyxl.load_workbook(filename)
        name = book.sheetnames[-1]
        book.remove(book[name])
        sheet = book.create_sheet(sheetname)
        sheet.append(title)
        for i in range(len(data)):
            sheet.append(data[i, :].tolist())  # write data
        book.save(filename=filename)

    # filter data from the original numpy array  
    def tool_filter(self, sheet, n_row, n_col):
        k = 0
        data = []
        for i in range(n_row):
            if sheet['A' + str(i + 1)].data_type == 'n':  # if it is a number
                data.append([])
                for j in range(n_col):
                    pos = chr(64 + j + 1) + str(i + 1)  # the position
                    val = sheet[pos].value
                    if sheet[pos].data_type == 'n':
                        data[k].append(val)
                k = k + 1
        return np.array(data)



# This function defines the operation model
# -----------------------------------------------------------------------------
#
def DistFlow_Model(model, Para, v_flow, hour, tp, obj):
    # Objective obj
    opr = gp.QuadExpr()       
    for n in range(Para.N_bus):
        ep_0 = v_flow[N_V_bus + n] - 1
        ep_1 = ep_0 * ep_0
        opr = opr + ep_1
    model.addConstr(obj[0] >= opr)


    # Constraint
    # 1. Nodal active power balance  
    for n in range(Para.N_bus):
        # Bus-Line information
        line_head = Para.Line_head[n]
        line_tail = Para.Line_tail[n]
        # Formulate expression 
        expr = gp.LinExpr()
        expr = expr - gp.quicksum(v_flow[N_P_line + i] for i in line_head)
        expr = expr + gp.quicksum(v_flow[N_P_line + i] for i in line_tail)
        for i in line_tail:
            expr = expr - v_flow[N_I_line + i] * Para.Line[i, 4]
        if n in Para.Sub[:, 1]:  # active power input from substation  
            i = int(np.where(n == Para.Sub[:, 1])[0])
            expr = expr + v_flow[N_P_sub + i]
        if n in Para.Gen[:, 1]:  # active power input from renewables
            i = int(np.where(n == Para.Gen[:, 1])[0]) 
            expr = expr + Para.Gen[i, 2] * Para.Day[hour, (int(Para.Gen[i, 3]) + 2)]* math.cos(Para.Factor)      
        model.addConstr(expr == Para.Bus[n, 1] * Para.Day[hour, 1])   

    # 2. Nodal reactive power balance 
    for n in range(Para.N_bus):
        # Bus-Line information
        line_head = Para.Line_head[n]
        line_tail = Para.Line_tail[n]
        # Formulate expression
        expr = gp.LinExpr()
        expr = expr - gp.quicksum(v_flow[N_Q_line + i] for i in line_head)
        expr = expr + gp.quicksum(v_flow[N_Q_line + i] for i in line_tail)
        for i in line_tail:
            expr = expr - v_flow[N_I_line + i] * Para.Line[i, 5]
        if n in Para.Sub[:, 1]:  # reactive power input from substation
            i = int(np.where(n == Para.Sub[:, 1])[0])
            expr = expr + v_flow[N_Q_sub + i]

        model.addConstr(expr == Para.Bus[n, 2] * Para.Day[hour, 1])   

    # 3. Branch flow equation  
    for n in range(Para.N_line):
        bus_head = Para.Line[n, 1]
        bus_tail = Para.Line[n, 2]
        # Formulate expression
        expr = gp.LinExpr()
        expr = expr + v_flow[N_V_bus + bus_head] - v_flow[N_V_bus + bus_tail]
        expr = expr - v_flow[N_P_line + n] * Para.Line[n, 4] * 2
        expr = expr - v_flow[N_Q_line + n] * Para.Line[n, 5] * 2
        expr = expr + v_flow[N_I_line + n] * (Para.Line[n, 4] ** 2)
        expr = expr + v_flow[N_I_line + n] * (Para.Line[n, 5] ** 2)
        model.addConstr(expr == 0)   

    # 4. Second order conic constraint 
    for n in range(Para.N_line):
        ep_0 = v_flow[N_P_line + n] * 2
        ep_1 = v_flow[N_Q_line + n] * 2
        ep_2 = v_flow[N_I_line + n] - v_flow[N_V_bus + Para.Line[n, 1]]
        ep_3 = v_flow[N_I_line + n] + v_flow[N_V_bus + Para.Line[n, 1]]
        model.addConstr(ep_0 * ep_0 + ep_1 * ep_1 + ep_2 * ep_2 <= ep_3 * ep_3)  

    # 6. Lower and Upper bound  
    # 1) voltage amplitutde  
    for n in range(Para.N_bus):
        model.addConstr(v_flow[N_V_bus + n] >= Para.V_min)
        model.addConstr(v_flow[N_V_bus + n] <= Para.V_max)
    # 2) line current
    for n in range(Para.N_line):
        Imax = 10
        model.addConstr(v_flow[N_I_line + n] >= 0)
        model.addConstr(v_flow[N_I_line + n] <= Imax)
    # 4) substation
    for n in range(Para.N_sub):
        smax = Para.Sub[n, 2]
        model.addConstr(v_flow[N_P_sub + n] >= -smax)
        model.addConstr(v_flow[N_P_sub + n] <= smax)
        model.addConstr(v_flow[N_Q_sub + n] >= -smax)
        model.addConstr(v_flow[N_Q_sub + n] <= smax)

        Nosubs = Para.Sub[n, 1]   
        model.addConstr(v_flow[N_V_bus + Nosubs] == (1.05 + tp * 0.0125) ** 2)   

    return model


# This class creates the Result class
# -----------------------------------------------------------------------------
#
class Result(object):

    # Initialization
    def __init__(self):
        pass

    # Obtain the value of variables
    def get_value(self, model, var, var_type):
        # Get value
        key = var.keys()
        val = var.copy()
        for i in range(len(key)):
            val[key[i]] = var[key[i]].x
        # Calculate dimention
        if isinstance(max(key), tuple):  # multi dimention
            dim = tuple([item + 1 for item in max(key)])
        if isinstance(max(key), int):  # one   dimention
            dim = tuple([int(len(key)), 1])
        # Convert dictionary to numpy array
        arr = np.zeros(dim, dtype=var_type)
        if var_type == "int":
            for i in range(len(val)):
                arr[key[i]] = int(round(val[key[i]]))
        else:
            for i in range(len(val)):
                arr[key[i]] = round(val[key[i]], 4)
        return arr


# This function defines the branch flow model  
# -----------------------------------------------------------------------------
#
def main_function(Para, hour, tp):
  
    model = gp.Model()

    # Operating variable 
    v_flow = model.addVars(N_N_var, lb=-1e2)
    # Set objective  
    obj = model.addVars(1)

    # Build Models
    # Build the model
    model = DistFlow_Model(model, Para, v_flow, hour, tp, obj)

    # Objective
    model.setObjective(obj.sum('*'), gp.GRB.MINIMIZE)

    # Optimization
    model.optimize()
    #model.computeIIS()
    #model.write("model1.ilp")
    if model.status == gp.GRB.Status.OPTIMAL or model.status == gp.GRB.Status.SUBOPTIMAL:    
        sol = Result()
        sol.v_flow = sol.get_value(model, v_flow, "float")
        sol.V_bus = sol.v_flow[N_V_bus: N_V_bus + Para.N_bus]
        sol.I_line = sol.v_flow[N_I_line: N_I_line + Para.N_line]
        sol.P_line = sol.v_flow[N_P_line: N_P_line + Para.N_line]
        sol.Q_line = sol.v_flow[N_Q_line: N_Q_line + Para.N_line]
        sol.P_sub = sol.v_flow[N_P_sub: N_P_sub + Para.N_sub]
        sol.Q_sub = sol.v_flow[N_Q_sub: N_Q_sub + Para.N_sub]

    else:
        sol = -1

    # #return sol
    if (sol == -1):
        return np.zeros((Para.N_bus,1))
    else:
        return np.sqrt(sol.V_bus)


if __name__ == "__main__":

    Para = Parameter("data/123nodedata.xlsx")
    tool = Excel_tool()
    ssol = main_function(Para, 167, -4)

    sol = np.zeros((123,9000))

    for i in range(9000):
        # Optimize
        ssol = main_function(Para, i)
        ssol_ = ssol.ravel()
        sol[:,i] = ssol_
    
    name = 'DDPG123nodebefore2.mat'
    sio.savemat(name,{'voltage':sol})